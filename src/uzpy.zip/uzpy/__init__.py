# this_file: src/uzpy/__init__.py

"""
uzpy: A tool to track where Python constructs are used and update docstrings.
"""

__version__ = "0.1.0"
__author__ = "Adam Twardoch"
