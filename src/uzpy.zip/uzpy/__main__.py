# this_file: src/uzpy/main.py

"""
Main entry point for the uzpy package.
"""

from uzpy.cli import cli

if __name__ == "__main__":
    cli()
